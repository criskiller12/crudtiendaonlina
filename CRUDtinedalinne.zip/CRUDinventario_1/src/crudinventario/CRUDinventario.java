
package crudinventario;
public class CRUDinventario {

    public static void main(String[] args)  {
        
    }
    
}
