/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author CROSTY
 */
public class Detallepedidos {
    private int iddetallepedidos;
    private int cantidad;
    private int idpedido;
    private float precio;
    private float total;
    private int idproducto;

    public Detallepedidos() {
        iddetallepedidos = 0;
        cantidad = 0;
        idpedido = 0;
        precio = 0;
        total = 0;
        idproducto = 0;
    }

    public int getIddetallepedidos() {
        return iddetallepedidos;
    }

    public void setIddetallepedidos(int iddetallepedidos) {
        this.iddetallepedidos = iddetallepedidos;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getIdpedido() {
        return idpedido;
    }

    public void setIdpedido(int idpedido) {
        this.idpedido = idpedido;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public int getIdproducto() {
        return idproducto;
    }

    public void setIdproducto(int idproducto) {
        this.idproducto = idproducto;
    }
    
    
}
