package Clases;

import java.sql.*;

public class ConexionBD {
    public static final String URL=
            "jdbc:mysql://127.0.0.1:3306/tiendaolineropa";
    public static final String USER="root";
    public static final String CLAVE="";
    private Connection con;
    
    public void ConectarBD(){
        con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection)DriverManager.getConnection(
                    URL, USER, CLAVE);
        } catch (Exception e) {
            System.out.println("Error Conectar: "+e.getMessage());
            //e.printStackTrace();
        }
    }
    
    public void DesconectarBD(){
        try {
            if(con.isClosed()==false){
                con.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public ResultSet ConsultaBD(String consulta){
        ResultSet resultado = null;
        try {
            Statement query = con.createStatement();
            resultado = query.executeQuery(consulta); //consulta
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultado; 
    }
    public boolean ValidarProducto(int idproducto){
        try {
            PreparedStatement query = con.prepareStatement("SELECT count(*) as total from productos "+
                " WHERE idproducto=?");
            query.setInt(1, idproducto);
            ResultSet res = query.executeQuery();
            if(res.next()){ //acceso al primer elemento
                if(res.getInt("total")>0){
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; 
    }
    
    public Productos ObtenerProducto(int idproducto){
        Productos p = new Productos();
        try {
            PreparedStatement query = con.prepareStatement("SELECT * from productos "+
                " WHERE idproducto=?");
            query.setInt(1, idproducto);
            ResultSet res = query.executeQuery();
            if(res.next()){ //acceso al primer elemento
                p.setIdproducto(res.getInt("idproducto"));
                p.setNombre(res.getString("nombre"));
                p.setDescripcion(res.getString("descripcion"));
                p.setCantidad(res.getInt("cantidad"));
                p.setEstado(res.getString("estado"));
                return p;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return p;
    }
    
    public Categoria ObtenerCategoria(String nombrecategoria){
        Categoria c = new Categoria();
        try {
            PreparedStatement query = con.prepareStatement("SELECT * from categoria "+
                " WHERE nombrecategoria=?");
            query.setString(1, nombrecategoria);
            ResultSet res = query.executeQuery();
            if(res.next()){ //acceso al primer elemento
                c.setIdcategoria(res.getInt("idCategoria"));
                c.setNombrecategoria(res.getString("nombrecategoria"));
                c.setEstado(res.getString("estado"));
                return c;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return c;
    }
    
    public Categoria ObtenerCategoriaporCodigo(String idcategoria){
        Categoria c = new Categoria();
        try {
            PreparedStatement query = con.prepareStatement("SELECT * from categoria "+
                " WHERE idcategoria=?");
            query.setString(1, idcategoria);
            ResultSet res = query.executeQuery();
            if(res.next()){ //acceso al primer elemento
                c.setIdcategoria(res.getInt("idcategoria"));
                c.setNombrecategoria(res.getString("descripcion"));
                c.setEstado(res.getString("estado"));
                return c;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return c;
    }
    
    public void EliminarProducto(int idproducto){
        try {
            PreparedStatement query = con.prepareStatement("DELETE from productos "+
                " WHERE idproducto=?");
            query.setInt(1, idproducto);
            query.executeUpdate();
            System.out.println("eliminados: "+query.getUpdateCount());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void ModificarProducto(int idproducto, String nombre, String descripcion, int idcategoria, int cantidad, String estado){
        try {
            PreparedStatement query = con.prepareStatement("UPDATE productos SET "+
                " nombre=?, "+
                " descripcion=?, "+
                " idcategoria=?, "+
                " cantidad=?, "+
                " estado=? "+
                "WHERE idproducto=?");
            query.setInt(1, idproducto);
            query.setString(2, nombre);
            query.setString(3, descripcion);
            query.setInt(4, idcategoria);
            query.setInt(5, cantidad);
            query.setString(6, estado);
            query.executeUpdate();
            System.out.println("modificados: "+query.getUpdateCount());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void InsertarProducto(int idproducto, String nombre, String descripcion, int idcategoria, int cantidad, String estado){
        try {
            PreparedStatement query = con.prepareStatement("INSERT INTO productos "+
                    "(idproducto,nombre,descripcion,idcategoria,cantidad,estado) "+
                    " VALUES (?,?,?,?,?,?)");
            query.setInt(1, idproducto);
            query.setString(2, nombre);
            query.setString(3, descripcion);
            query.setInt(4, idcategoria);
            query.setInt(5, cantidad);
            query.setString(6, estado);
            query.executeUpdate();
            System.out.println("modificados: "+query.getUpdateCount());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public boolean Validardetallepedido(int iddetallepedidos){
        try {
            PreparedStatement query = con.prepareStatement("SELECT count(*) as total from detallepedidos "+
                " WHERE iddetallepedidos=?");
            query.setInt(1, iddetallepedidos);
            ResultSet res = query.executeQuery();
            if(res.next()){ //acceso al primer elemento
                if(res.getInt("total")>0){
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; 
    }
    
    public Detallepedidos ObtenerDetallepedido(int iddetallepedidos){
        Detallepedidos p = new Detallepedidos();
        try {
            PreparedStatement query = con.prepareStatement("SELECT * from detallepedidos "+
                " WHERE iddetallepedidos=?");
            query.setInt(1, iddetallepedidos);
            ResultSet res = query.executeQuery();
            if(res.next()){ //acceso al primer elemento
                p.setIddetallepedidos(res.getInt("iddetallepedidos"));
                p.setCantidad(res.getInt("cantidad"));
                p.setPrecio(res.getFloat("precio"));
                p.setTotal(res.getFloat("total"));
                return p;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return p;
    }
    
    public Pedidos ObtenerPedidos(String valortotal){
        Pedidos c = new Pedidos();
        try {
            PreparedStatement query = con.prepareStatement("SELECT * from pedidos "+
                " WHERE valortotal=?");
            query.setString(1, valortotal);
            ResultSet res = query.executeQuery();
            if(res.next()){ //acceso al primer elemento
                c.setIdpedido(res.getInt("idpedido"));
                c.setValortotal(res.getString("valortotal"));
                c.setEstado(res.getInt("estado"));
                c.setFecha(res.getString("fecha"));
                return c;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return c;
    }
    
    public Pedidos ObtenerPedidos(int idpedido){
        Pedidos c = new Pedidos();
        try {
            PreparedStatement query = con.prepareStatement("SELECT * from pedidos "+
                " WHERE idpedido=?");
            query.setInt(1, idpedido);
            ResultSet res = query.executeQuery();
            if(res.next()){ //acceso al primer elemento
                c.setIdpedido(res.getInt("idpedido"));
                c.setValortotal(res.getString("valortotal"));
                c.setEstado(res.getInt("estado"));
                c.setFecha(res.getString("fecha"));
                return c;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return c;
    }
    
    public void EliminarDetallepedido(int iddetallepedidos){
        try {
            PreparedStatement query = con.prepareStatement("DELETE from detallepedidos "+
                " WHERE iddetallepedidos=?");
            query.setInt(1, iddetallepedidos);
            query.executeUpdate();
            System.out.println("eliminados: "+query.getUpdateCount());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void Modificardetallepedidos(int iddetallepedidos, int cantidad, int idpedidos, float precio, float total){
        try {
            PreparedStatement query = con.prepareStatement("UPDATE detallepedidos SET "+
                " cantidad=?, "+
                " idpedidos=?, "+
                " precio=?, "+
                " total=? "+
                "WHERE iddetallepedidos=?");
            query.setInt(1, iddetallepedidos);
            query.setInt(2, cantidad);
            query.setInt(3, idpedidos);
            query.setFloat(4, precio);
            query.setFloat(5, total);
            query.executeUpdate();
            System.out.println("modificados: "+query.getUpdateCount());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void InsertarDetallepedidos(int iddetallepedidos, int cantidad, int idpedidos, float precio, float total){
        try {
            PreparedStatement query = con.prepareStatement("INSERT INTO detallepedidos "+
                    "(iddetallepedidos,cantidad,idpedidos,precio,total) "+
                    " VALUES (?,?,?,?,?)");
            query.setInt(1, iddetallepedidos);
            query.setInt(2, cantidad);
            query.setInt(3, idpedidos);
            query.setFloat(4, precio);
            query.setFloat(5, total);
            query.executeUpdate();
            System.out.println("modificados: "+query.getUpdateCount());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
}

